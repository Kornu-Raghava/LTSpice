* ---- nfit : copy of PTM nmos, made to describe the TCAD device (Step 0) ----
* Original card (65nm_bulk_organized.pm) is NOT modified; nmos stays for reference overlays.
* Parameters in {braces} are the tuning knobs (module 6.2 order: VTH0 -> NFACTOR/VOFF -> ETA0 -> U0/VSAT/PCLM)
.param pvth0=0.423 pnfac=1.9 pvoff=-0.13 peta0=0.0058 pu0=0.0491 pvsat=124340 ppclm=0.04
.model nfit nmos level=54
+version=4.0 binunit=1 paramchk=1 mobmod=0 capmod=2 igcmod=0 igbmod=0 geomod=1
+diomod=1 rdsmod=0 rbodymod=0 rgatemod=0 permod=1 acnqsmod=0 trnqsmod=0
+tnom=27 toxe=5e-9 toxp=5e-9 toxm=5e-9 dtox=0 epsrox=3.9 toxref=5e-9
+wint=5e-9 lint=5.25e-9 ll=0 wl=0 lln=1 wln=1 lw=0 ww=0 lwn=1 wwn=1 lwl=0 wwl=0 xl=-30e-9
+vth0={pvth0} k1=0.4 k2=0.01 k3=0 k3b=0 w0=2.5e-6 dvt0=1 dvt1=2 dvt2=-0.032
+dvt0w=0 dvt1w=0 dvt2w=0 dsub=0.1 minv=0.05 voffl=0 dvtp0=1e-9 dvtp1=0.1 lpe0=0 lpeb=0
+xj=1.96e-8 ngate=2e20 ndep=2.54e18 nsd=2e20 phin=0 cdsc=0 cdscb=0 cdscd=0 cit=0
+voff={pvoff} nfactor={pnfac} eta0={peta0} etab=0 vfb=-0.55
+u0={pu0} ua=6e-10 ub=1.2e-18 uc=0
+vsat={pvsat} a0=1 ags=1e-20 a1=0 a2=1 b0=0 b1=0 keta=0.04 dwg=0 dwb=0
+pclm={ppclm} pdiblc1=0.001 pdiblc2=0.001 pdiblcb=-0.005 drout=0.5 pvag=1e-20 delta=0.01
+pscbe1=8.14e8 pscbe2=1e-7 fprout=0.2 pdits=0.08 pditsd=0.23 pditsl=2.3e6
+rsh=5 rdsw=165 rsw=85 rdw=85 rdswmin=0 rdwmin=0 rswmin=0 prwg=0 prwb=6.8e-11 wr=1
+alpha0=0.074 alpha1=0.005 beta0=30 agidl=0.0002 bgidl=2.1e9 cgidl=0.0002 egidl=0.8
+cgso=1.5e-10 cgdo=1.5e-10 cgbo=2.56e-11 cgdl=2.653e-10 cgsl=2.653e-10
+kt1=-0.11 kt1l=0 kt2=0.022 ute=-1.5 ua1=4.31e-9 ub1=7.61e-18 uc1=-5.6e-11 prt=0 at=33000
+jss=1e-4 jsws=1e-11 jswgs=1e-10 njs=1 jsd=1e-4 jswd=1e-11 jswgd=1e-10 njd=1
