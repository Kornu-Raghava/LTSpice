import pandas as pd
import matplotlib.pyplot as plt

# 1. Read LTspice exports (tab-separated) and TCAD CSVs (comma-separated)
sp_vg = pd.read_csv("idvg.txt", sep="\t")
tc_vg = pd.read_csv("idvg_real.csv")

sp_vd = pd.read_csv("idvd.txt", sep="\t")
tc_vd = pd.read_csv("idvd_real.csv")

# Optional: save clean SPICE CSVs with positive currents
sp_vg.columns = ["Vg", "PTM", "nfit"]
sp_vg[["PTM", "nfit"]] = sp_vg[["PTM", "nfit"]].abs()
sp_vg.to_csv("spice_idvg.csv", index=False)

sp_vd.columns = ["Vd", "PTM", "nfit"]
sp_vd[["PTM", "nfit"]] = sp_vd[["PTM", "nfit"]].abs()
sp_vd.to_csv("spice_idvd.csv", index=False)

# 2. Plot side-by-side overlays (linear axes, A/um -> uA/um)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

# Left: Id-Vg overlay at Vds = 0.4 V
ax1.plot(sp_vg["Vg"], sp_vg["PTM"] * 1e6, "--", color="gray", label="PTM")
ax1.plot(sp_vg["Vg"], sp_vg["nfit"] * 1e6, "-",
         color="black", label="SPICE nfit")
ax1.plot(tc_vg.iloc[:, 0], tc_vg.iloc[:, 1] * 1e6, "o",
         mfc="none", mec="black", ms=4, label="TCAD")
ax1.set_xlabel("VGS (V)")
ax1.set_ylabel("ID (uA/um)")
ax1.set_title("Id-Vg at Vds = 0.4 V")
ax1.set_xlim(0, 1.5)
ax1.legend()
ax1.grid(True)

# Right: Id-Vd overlay at Vgs = 0.9 V
ax2.plot(sp_vd["Vd"], sp_vd["PTM"] * 1e6, "--", color="gray", label="PTM")
ax2.plot(sp_vd["Vd"], sp_vd["nfit"] * 1e6, "-",
         color="black", label="SPICE nfit")
ax2.plot(tc_vd.iloc[:, 0], tc_vd.iloc[:, 1] * 1e6, "o",
         mfc="none", mec="black", ms=4, label="TCAD")
ax2.set_xlabel("VDS (V)")
ax2.set_ylabel("ID (uA/um)")
ax2.set_title("Id-Vd at Vgs = 0.9 V")
ax2.set_xlim(0, 1.5)
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.savefig("s6_overlay.png", dpi=300)
plt.show()
