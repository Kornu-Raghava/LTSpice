import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# LTspice export: tab-separated, with "Step Information" lines between sweeps
# Stepped parameter in this file: Xl
FILE = r"C:\Users\Satya\Documents\LTspice\EDA\S5\Id_Vd\p4.csv"
PARAM = "Xl"

rows, label = [], None
# latin-1 so special characters such as the micro sign (u) are read correctly
with open(FILE, encoding="latin-1") as f:
    next(f)  # skip header line
    for line in f:
        line = line.strip()
        if line.startswith("Step Information"):
            label = line.split(PARAM + "=")[1].split()[0]  # e.g. 1.5n
        elif line:
            parts = line.split("\t")
            rows.append((label, float(parts[0]), float(parts[-1])))  # Vd, Id

df = pd.DataFrame(rows, columns=[PARAM, "Vd", "Id"])

fig, ax = plt.subplots(figsize=(6.5, 4.5))

for val, g in df.groupby(PARAM, sort=False):
    ax.plot(g["Vd"], np.asarray(g["Id"]) * 1e3, label=f"{PARAM} = {val}")

ax.set(xlabel="Vd (V)", ylabel="Id (mA)", title=f"Id-Vd, {PARAM} sweep")
ax.grid(True, alpha=0.3)
ax.legend()

plt.tight_layout()
plt.savefig(r'C:\Users\Satya\Downloads\S5\Id_Vd_P4', dpi=300)
plt.show()
