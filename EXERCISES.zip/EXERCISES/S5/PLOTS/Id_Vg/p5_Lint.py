import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# LTspice export: tab-separated, with "Step Information" lines between sweeps
# Stepped parameter in this file: Lint
FILE = r"C:\Users\Satya\Documents\LTspice\EDA\S5\Id_Vg\p5.csv"
PARAM = "Lint"

rows, label = [], None
# latin-1 so special characters such as the micro sign (u) are read correctly
with open(FILE, encoding="latin-1") as f:
    next(f)  # skip header line
    for line in f:
        line = line.strip()
        if line.startswith("Step Information"):
            label = line.split(PARAM + "=")[1].split()[0]  # e.g. 1.5n
        elif line:
            parts = line.split("\t")
            rows.append((label, float(parts[0]), float(parts[-1])))  # Vg, Id

df = pd.DataFrame(rows, columns=[PARAM, "Vg", "Id"])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

for val, g in df.groupby(PARAM, sort=False):
    ax1.plot(g["Vg"], g["Id"] * 1e3, label=f"{PARAM} = {val}")
    ax2.semilogy(g["Vg"], np.abs(g["Id"]), label=f"{PARAM} = {val}")

ax1.set(xlabel="Vg (V)", ylabel="Id (mA)",
        title=f"Id-Vg (linear), {PARAM} sweep")
ax2.set(xlabel="Vg (V)", ylabel="Id (A)",
        title=f"Id-Vg (log scale), {PARAM} sweep")
for ax in (ax1, ax2):
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()

plt.tight_layout()
plt.savefig(r"C:\Users\Satya\Downloads\S5\Id_Vg_P5", dpi=300)
plt.show()
