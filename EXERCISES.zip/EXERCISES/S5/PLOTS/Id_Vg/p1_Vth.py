import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# LTspice-style export: tab-separated, with "Step Information" lines between sweeps
FILE = r"C:\Users\Satya\Documents\LTspice\EDA\S5\Id_Vg\p1.csv"

rows, vth_label = [], None
with open(FILE) as f:
    next(f)  # skip header line (Vg  V(g)  Id(M1))
    for line in f:
        line = line.strip()
        if line.startswith("Step Information"):
            vth_label = line.split("Vth=")[1].split()[0]  # e.g. 300m
        elif line:
            vg, _, id_ = line.split("\t")
            rows.append((vth_label, float(vg), float(id_)))

df = pd.DataFrame(rows, columns=["Vth", "Vg", "Id"])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

for vth, g in df.groupby("Vth", sort=False):
    vth_val = float(vth.replace("m", "e-3"))
    ax1.plot(g["Vg"], g["Id"] * 1e3, label=f"Vth = {vth_val:.3f} V")
    ax2.semilogy(g["Vg"], np.abs(g["Id"]), label=f"Vth = {vth_val:.3f} V")

ax1.set(xlabel="Vg (V)", ylabel="Id (mA)", title="Id-Vg (linear)")
ax2.set(xlabel="Vg (V)", ylabel="Id (A)", title="Id-Vg (log scale)")
for ax in (ax1, ax2):
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()

plt.tight_layout()
plt.savefig(r"C:\Users\Satya\Downloads\S5\Id_Vg_P1", dpi=300)
plt.show()
