import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

FILE = r"C:\Users\Satya\Documents\LTspice\EDA\S5\Id_Vg\p2.csv"

rows, tox_label = [], None
with open(FILE) as f:
    next(f)  # skip header line
    for line in f:
        line = line.strip()
        if line.startswith("Step Information"):
            tox_label = line.split("Toxe=")[1].split()[0]  # e.g. 1.5n
        elif line:
            vg, _, id_ = line.split("\t")
            rows.append((tox_label, float(vg), float(id_)))

df = pd.DataFrame(rows, columns=["Toxe", "Vg", "Id"])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

for tox, g in df.groupby("Toxe", sort=False):
    tox_nm = float(tox.replace("n", ""))  # label is already in nm
    ax1.plot(g["Vg"], g["Id"] * 1e3, label=f"Toxe = {tox_nm:g} nm")
    ax2.semilogy(g["Vg"], np.abs(g["Id"]), label=f"Toxe = {tox_nm:g} nm")

ax1.set(xlabel="Vg (V)", ylabel="Id (mA)", title="Id-Vg (linear)")
ax2.set(xlabel="Vg (V)", ylabel="Id (A)", title="Id-Vg (log scale)")
for ax in (ax1, ax2):
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()

plt.tight_layout()
plt.savefig(r"C:\Users\Satya\Downloads\S5\Id_Vg_P2", dpi=300)
plt.show()
