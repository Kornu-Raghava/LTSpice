import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 1. Load and split both Vds steps directly with pandas (comment="S" skips Step headers)
df = pd.read_csv(
    r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S4\Id_Vg_u_changed.csv", sep="\t", comment="S")
step = df.groupby("Vg").cumcount()
df1 = df[step == 0]   # Vds = 50 mV
df2 = df[step == 1]   # Vds = 1.1 V

vg1, id1 = df1["Vg"].to_numpy(), df1["Id(M1)"].to_numpy()
vg2, id2 = df2["Vg"].to_numpy(), df2["Id(M1)"].to_numpy()

# 2. E9: Transconductance gm = dID / dVGS (at Vds = 50 mV)
gm1 = np.gradient(id1, vg1)
gm2 = np.gradient(id2, vg2)
k = gm1.argmax()
vgs_peak, gm_peak = vg1[k], gm1[k]

# 3. E10: Linear extrapolation VT using np.polyfit around peak gm (no np.polyval)
m, b = np.polyfit(vg1[k - 5: k + 6], id1[k - 5: k + 6], 1)
vth_lin = -b / m
vg_tan = np.linspace(vth_lin, vg1[k + 5], 50)
id_tan = m * vg_tan + b

print(f"Mobility-modified (u_changed):")
print(f"  Peak gm (50 mV) = {gm_peak * 1e3:.3f} mS at VGS = {vgs_peak:.3f} V")
print(f"  Extracted VT    = {vth_lin:.3f} V")

# 4. Side-by-side subplots (E9 & E10)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

ax1.plot(vg1, id1 * 1e3, label="Vds = 50 mV")
ax1.plot(vg2, id2 * 1e3, "--", label="Vds = 1.1 V")
ax1.plot(vg_tan, id_tan * 1e3, ":", color="green",
         label=f"Tangent (VT = {vth_lin:.3f} V)")
ax1.scatter([vth_lin], [0], color="red", zorder=5)
ax1.set_xlabel("Gate Voltage VGS (V)")
ax1.set_ylabel("Drain Current ID (mA)")
ax1.set_title("ID vs VGS & VT Extraction (u_changed)")
ax1.legend()
ax1.grid(True)

ax2.plot(vg1, gm1 * 1e3, label="gm (Vds = 50 mV)")
ax2.plot(vg2, gm2 * 1e3, "--", label="gm (Vds = 1.1 V)")
ax2.scatter([vgs_peak], [gm_peak * 1e3], color="red", zorder=5,
            label=f"Peak gm = {gm_peak * 1e3:.2f} mS @ {vgs_peak:.3f} V")
ax2.set_xlabel("Gate Voltage VGS (V)")
ax2.set_ylabel("Transconductance gm (mS)")
ax2.set_title("Transconductance gm vs VGS (u_changed)")
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.savefig(
    r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S4\Id_Vg_u_changed_plot.png", dpi=300)
plt.show()
