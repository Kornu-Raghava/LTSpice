import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

files = {
    0.3: r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\Id_Vd_0.3V.csv",
    0.6: r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\Id_Vd_0.6V.csv",
    0.9: r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\Id_Vd_0.9V.csv",
    1.5: r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\Id_Vd_1.5V.csv",
}

fig1, ax1 = plt.subplots()
fig2, ax2 = plt.subplots()

for vgs, fname in files.items():
    df = pd.read_csv(fname, sep="\t", comment="S")
    vd, id_ = df["Vd"].to_numpy(), df["Id(M1)"].to_numpy()
    gd = np.gradient(id_, vd)

    ax1.plot(vd, id_ * 1e3, label=f"VGS = {vgs} V")
    ax2.plot(vd, gd * 1e3, label=f"VGS = {vgs} V")

# E8: ro = 1 / gd in saturation at the highest VGS (1.5 V, end of sweep VD = 1.1 V)
ro = 1.0 / gd[-1]
print(f"ro (at VGS = 1.5 V, saturation) = {ro / 1e3:.2f} kOhm")

# Figure 1: Output characteristics (E7)
ax1.set_xlabel("VDS (V)")
ax1.set_ylabel("ID (mA)")
ax1.set_title("Output Characteristics (ID vs VDS)")
ax1.legend()
ax1.grid(True)
fig1.savefig(
    r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\output_char.png", dpi=300)

# Figure 2: Output conductance (E8)
ax2.set_xlabel("VDS (V)")
ax2.set_ylabel("gd (mS)")
ax2.set_title("Output Conductance (gd vs VDS)")
ax2.legend()
ax2.grid(True)
fig2.savefig(
    r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S3\output_conductance.png", dpi=300)

plt.show()
