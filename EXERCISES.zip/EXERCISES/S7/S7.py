import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 1. Read LTspice export directly using column names
df = pd.read_csv("inv.txt", sep="\t")
vin = df["V(vin)"].to_numpy()
vout = df["V(vout)"].to_numpy()

# 2. Extract inverter VTC parameters
gain = np.gradient(vout, vin)
vm = vin[np.argmin(np.abs(vout - vin))]
voh, vol = vout[0], vout[-1]

steep = vin[gain <= -1]
vil, vih = steep[0], steep[-1]

print(f"VOH = {voh:.3f} V,  VOL = {vol:.4f} V,  VM = {vm:.3f} V")
print(f"Max gain = {gain.min():.1f},  VIL = {vil:.3f} V,  VIH = {vih:.3f} V")
print(f"NML = {vil - vol:.3f} V,  NMH = {voh - vih:.3f} V")

# 3. Plot VTC
plt.figure()
plt.plot(vin, vout, label="Vout")
plt.plot(vin, vin, "--", label="Vout = Vin")
plt.plot(vm, vm, "ro", label=f"VM = {vm:.2f} V")
plt.xlabel("Vin (V)")
plt.ylabel("Voltage (V)")
plt.title("CMOS Inverter VTC")
plt.legend()
plt.grid(True)
plt.savefig("S7_inverter.png", dpi=300, bbox_inches="tight")
plt.show()