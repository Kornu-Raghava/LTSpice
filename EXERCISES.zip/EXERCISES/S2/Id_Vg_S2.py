import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Read both LTspice sweep files directly (comment="S" skips "Step Information" lines)
df1 = pd.read_csv(r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S2\Id_Vg_0.05V.csv",
                  sep="\t", comment="S").drop_duplicates("Vg")
df2 = pd.read_csv(r"C:\Users\Satya\Documents\LTspice\EDA\EXERCISES\S2\Id_Vg_1.1V.csv",
                  sep="\t", comment="S").drop_duplicates("Vg")

vg1, id1 = df1["Vg"].to_numpy(), df1["Id(M1)"].to_numpy()
vg2, id2 = df2["Vg"].to_numpy(), df2["Id(M1)"].to_numpy()

# Extraction using only np.polyfit (no np.interp, no np.polyval)
Icc = 100e-9 * 1e-6 / 65e-9  # 100 nA * W/L

# Constant-current VTH at VDS = 50 mV and VDS = 1.1 V
i1 = np.argsort(np.abs(np.log10(id1) - np.log10(Icc)))[:5]
m1, b1 = np.polyfit(np.log10(id1[i1]), vg1[i1], 1)
vth1 = m1 * np.log10(Icc) + b1

i2 = np.argsort(np.abs(np.log10(id2) - np.log10(Icc)))[:5]
m2, b2 = np.polyfit(np.log10(id2[i2]), vg2[i2], 1)
vth2 = m2 * np.log10(Icc) + b2

# Linear-extrapolation VTH from tangent around peak gm
gm = np.gradient(id1, vg1)
k = gm.argmax()
m, b = np.polyfit(vg1[k - 5: k + 6], id1[k - 5: k + 6], 1)
vth_lin = -b / m

# ION (VG = 1.1 V) and IOFF (VG = 0.0 V) at VDS = 1.1 V
m_on, b_on = np.polyfit(vg2[-5:], id2[-5:], 1)
ion = m_on * 1.1 + b_on

m_off, b_off = np.polyfit(vg2[:5], id2[:5], 1)
ioff = m_off * 0.0 + b_off

print(f"VTH,lin (50 mV) = {vth_lin:.3f} V")
print(f"VTH,cc  (50 mV) = {vth1:.3f} V")
print(f"VTH,cc  (1.1 V) = {vth2:.3f} V")
print(f"DIBL = {(vth1 - vth2) / 1.05 * 1e3:.1f} mV/V")
print(f"ION  = {ion * 1e3:.3f} mA/um")
print(f"IOFF = {ioff * 1e9:.1f} nA/um")

# Tangent line for linear VTH visualization
vg_tan = np.linspace(vth_lin, vg1[k + 5], 50)
id_tan = m * vg_tan + b

# Side-by-side Linear and Log overlay plots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

ax1.plot(vg1, id1 * 1e3, label="VDS = 50 mV")
ax1.plot(vg2, id2 * 1e3, label="VDS = 1.1 V")
ax1.plot(vg_tan, id_tan * 1e3, "--",
         label=f"Tangent (VTH,lin = {vth_lin:.3f} V)")
ax1.scatter([vth_lin], [0], color="red", zorder=5)
ax1.set_xlabel("VG (V)")
ax1.set_ylabel("ID (mA/um)")
ax1.set_title("ID-VG Overlay (Linear)")
ax1.legend()
ax1.grid(True)

ax2.semilogy(vg1, id1, label="VDS = 50 mV")
ax2.semilogy(vg2, id2, label="VDS = 1.1 V")
ax2.axhline(Icc, color="gray", linestyle=":",
            label=f"Icc = {Icc * 1e6:.2f} uA/um")
ax2.scatter([vth1, vth2], [Icc, Icc], color="red", zorder=5)
ax2.set_xlabel("VG (V)")
ax2.set_ylabel("ID (A/um)")
ax2.set_title("ID-VG Overlay (Log)")
ax2.legend()
ax2.grid(True, which="both")

plt.tight_layout()
plt.savefig("Id_Vg_S2_overlay.png", dpi=300, bbox_inches="tight")
plt.show()
